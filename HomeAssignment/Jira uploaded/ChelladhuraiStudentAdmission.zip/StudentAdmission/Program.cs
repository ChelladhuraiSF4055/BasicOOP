﻿using System;
using System.Collections.Generic;
namespace StudentAdmission;

class Program
{
    public static void Main(string[] args)
    {
        //Buying files for operations
        Operations.DefaultData();
        Operations.MainMenu();
    }
}
