﻿using System;
using System.Collections.Generic;
namespace Ecommerce;
class Program{
    public static void Main(string[] args)
    {
      Operations.DefaultData();
      
      Operations.MainMenu();
    
    }
}